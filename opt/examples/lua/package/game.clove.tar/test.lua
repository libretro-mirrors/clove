
test = {}

function test.load()
	print("Test 1!")
end

function test.draw()
	love.graphics.circle("fill",250,250,120,10)
end