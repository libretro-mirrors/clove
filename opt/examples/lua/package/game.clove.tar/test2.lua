
test2 = {}

function test2.load()
	print("Test 2!")
end

function test2.draw()
	love.graphics.circle("line",250,450,50,20)
end